@echo off
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0download_readings.ps1"
pause
