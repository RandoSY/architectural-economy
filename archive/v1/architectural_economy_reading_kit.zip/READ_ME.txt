Architectural Economy reading library

1. Extract the ZIP.
2. Open architectural_economy_reading_library.html in your browser.
3. To attempt batch downloading 9 PDF links, open PowerShell in the extracted folder and run: powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\download_readings.ps1
   Or double-click Download_Readings.cmd. Windows may block downloaded scripts; use the HTML links instead if that occurs.
4. Downloads go into Papers. The script checks each downloaded file for a PDF header, and reports failures.

No third-party PDF files are included in this ZIP. Network access in the chat environment was unavailable. The download script has not been tested against the live servers. Some hosts may require browser access or restrict automated downloads.
