$ErrorActionPreference = 'Continue'
$dest = Join-Path $PSScriptRoot 'Papers'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$files = @(
  @{Name='Yan_2010.pdf'; Url='https://archive.gersteinlab.org/papers/e-print/callgraph/preprint.pdf'},
  @{Name='Istrail_2007.pdf'; Url='https://cs.brown.edu/research/pubs/pdfs/2007/Istrail-2007-RGC.pdf'},
  @{Name='Davidson_Erwin_2006.pdf'; Url='https://lnx00.cecm.usp.br/~cewinter/aulas/artigos/2006/gene_reg_ntwrk.pdf'},
  @{Name='Kirschner_Gerhart_1998.pdf'; Url='https://science.umd.edu/classroom/bsci338-biol708/Kirshner-Gerhart-Evolvability-PNAS1998.pdf'},
  @{Name='Kitano_2004.pdf'; Url='https://www-users.york.ac.uk/~lsdc1/SysBiol/kitano.robustness.naturegenetics.2004.pdf'},
  @{Name='Enhancer_Action_2021.pdf'; Url='https://link.springer.com/content/pdf/10.1186/s13059-021-02322-1.pdf'},
  @{Name='Bell_DEC_1978.pdf'; Url='https://bitsavers.trailing-edge.com/pdf/dec/_Books/Bell-ComputerEngineering.pdf'},
  @{Name='DEC_Handbook_1967.pdf'; Url='https://bitsavers.trailing-edge.com/pdf/dec/pdp8/handbooks/SmallComputerHandbook_Mar67.pdf'},
  @{Name='Simon_1962.pdf'; Url='https://www.andrew.cmu.edu/course/15-440/assets/READINGS/simon-architecture-of-complexity-1962.pdf'}
 )
foreach ($f in $files) {
  $out = Join-Path $dest $f.Name
  $tmp = $out + '.part'
  try {
    Write-Host ('Downloading ' + $f.Name)
    Invoke-WebRequest -UseBasicParsing -Uri $f.Url -OutFile $tmp -TimeoutSec 180 -ErrorAction Stop
    $stream = [IO.File]::OpenRead($tmp)
    try { $header = New-Object byte[] 5; $n = $stream.Read($header,0,5) } finally { $stream.Dispose() }
    if ($n -ne 5 -or [Text.Encoding]::ASCII.GetString($header) -ne '%PDF-') { throw 'Response was not a PDF; open the source in your browser.' }
    Move-Item -Force $tmp $out
    Write-Host ('Saved ' + $f.Name)
  } catch {
    Remove-Item $tmp -ErrorAction SilentlyContinue
    Write-Warning ($f.Name + ': ' + $_.Exception.Message)
  }
}
Write-Host ('Files are in ' + $dest)
Write-Host 'Use the HTML reading index for remaining articles or failed downloads.'
